#ifndef BYTES_HPP
#define BYTES_HPP

#include <vector>
// to be removed
//typedef std::vector<unsigned char> bytes;

typedef unsigned char Byte;
typedef std::vector<Byte> Bytes;

#endif
