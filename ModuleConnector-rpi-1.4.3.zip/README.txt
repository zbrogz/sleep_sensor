See <ModuleConnector root>\doc\html\index.xhtml for ModuleConnector documentation.
