var searchData=
[
  ['enum_5fbegin',['ENUM_BEGIN',['../datatypes_8h.xhtml#a47a6e814c0d9f590c277241dab1e9818',1,'datatypes.h']]],
  ['enum_5fend',['ENUM_END',['../datatypes_8h.xhtml#ae74fd9930a74a617b7facaeacfaf159d',1,'datatypes.h']]]
];
