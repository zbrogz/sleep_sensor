var searchData=
[
  ['carrier_5ffrequency',['carrier_frequency',['../class_xe_thru_1_1_baseband_ap_data.xhtml#a902e1584ac633e1ad6801c84362b67b8',1,'XeThru::BasebandApData::carrier_frequency()'],['../class_xe_thru_1_1_baseband_iq_data.xhtml#a5b0f5aa0f7b2ba04fdf11cd2b81d4e99',1,'XeThru::BasebandIqData::carrier_frequency()']]],
  ['changelog',['Changelog',['../changelog.xhtml',1,'']]],
  ['changelog_2emd',['CHANGELOG.md',['../_c_h_a_n_g_e_l_o_g_8md.xhtml',1,'']]],
  ['clear',['clear',['../class_xe_thru_1_1_x2_m200.xhtml#a20cf9bce35a3de767ffba16b11b3c109',1,'XeThru::X2M200']]],
  ['clear_5fbasename_5ffor_5fdata_5ftypes',['clear_basename_for_data_types',['../class_xe_thru_1_1_data_recorder.xhtml#a2a2af7eebc1d244f31db53d1237278a1',1,'XeThru::DataRecorder']]],
  ['close',['close',['../class_xe_thru_1_1_data_reader.xhtml#a8e01deed041ff7cf5d82154e82b4c375',1,'XeThru::DataReader::close()'],['../class_xe_thru_1_1_module_connector.xhtml#afd152a95595e8aeac7274e00c16f017e',1,'XeThru::ModuleConnector::close()']]],
  ['close_5ffile',['close_file',['../class_xe_thru_1_1_x_e_p.xhtml#a71f642ff208ad65ea2725eddb66f6731',1,'XeThru::XEP']]],
  ['content_5fid',['content_id',['../struct_xe_thru_1_1_data_float.xhtml#ac1b5a2d971b64d156bc9940f13d7bdd4',1,'XeThru::DataFloat']]],
  ['counter',['counter',['../struct_xe_thru_1_1_respiration_moving_list_data.xhtml#a01e91d0b5bd180f3ced73c9f89bcc3d1',1,'XeThru::RespirationMovingListData::counter()'],['../struct_xe_thru_1_1_respiration_detection_list_data.xhtml#a2bd84bf019a02402a9ef2922ebef3359',1,'XeThru::RespirationDetectionListData::counter()']]],
  ['create_5ffile',['create_file',['../class_xe_thru_1_1_x_e_p.xhtml#a7e237ed17b416dc51af5aa833b83ad40',1,'XeThru::XEP']]],
  ['compiling_20and_20linking_20moduleconnector_20with_20c_2b_2b',['Compiling and linking ModuleConnector with C++',['../link_cpp.xhtml',1,'']]]
];
