var searchData=
[
  ['phase',['phase',['../class_xe_thru_1_1_baseband_ap_data.xhtml#acbf60908100d228d180a95f145eeac44',1,'XeThru::BasebandApData']]],
  ['presence_5fstate',['presence_state',['../class_xe_thru_1_1_presence_single_data.xhtml#af88d82b91801e7e310858af7de190899',1,'XeThru::PresenceSingleData::presence_state()'],['../class_xe_thru_1_1_presence_moving_list_data.xhtml#a4a2c5cc49f2d12b438d0fb33dfcc3d87',1,'XeThru::PresenceMovingListData::presence_state()']]],
  ['pulsedoppler_5finstance',['pulsedoppler_instance',['../class_xe_thru_1_1_pulse_doppler_float_data.xhtml#ad43224e52053d2d2400d986e2ca63f13',1,'XeThru::PulseDopplerFloatData::pulsedoppler_instance()'],['../class_xe_thru_1_1_pulse_doppler_byte_data.xhtml#aae13687d8285203b7bc05e41b0dbd579',1,'XeThru::PulseDopplerByteData::pulsedoppler_instance()']]]
];
