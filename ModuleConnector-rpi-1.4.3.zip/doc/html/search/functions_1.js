var searchData=
[
  ['basebandapdata',['BasebandApData',['../class_xe_thru_1_1_baseband_ap_data.xhtml#a6417943b3f45b8e873726fda89de9cc4',1,'XeThru::BasebandApData::BasebandApData()'],['../class_xe_thru_1_1_baseband_ap_data.xhtml#a00bf476e950a70db8751b64eb47974db',1,'XeThru::BasebandApData::BasebandApData(uint32_t frame_counter, uint32_t num_bins, float bin_length, float sample_frequency, float carrier_frequency, float range_offset, const float *amplitude, const float *phase)']]],
  ['basebandiqdata',['BasebandIqData',['../class_xe_thru_1_1_baseband_iq_data.xhtml#aa6d11e58bf58dca5631e061a251eeef6',1,'XeThru::BasebandIqData::BasebandIqData()'],['../class_xe_thru_1_1_baseband_iq_data.xhtml#a32cf74ed624ca827b14cf9adae92e0ce',1,'XeThru::BasebandIqData::BasebandIqData(uint32_t frame_counter, uint32_t num_bins, float bin_length, float sample_frequency, float carrier_frequency, float range_offset, const float *i, const float *q)']]]
];
