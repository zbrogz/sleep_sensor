var searchData=
[
  ['carrier_5ffrequency',['carrier_frequency',['../class_xe_thru_1_1_baseband_ap_data.xhtml#a902e1584ac633e1ad6801c84362b67b8',1,'XeThru::BasebandApData::carrier_frequency()'],['../class_xe_thru_1_1_baseband_iq_data.xhtml#a5b0f5aa0f7b2ba04fdf11cd2b81d4e99',1,'XeThru::BasebandIqData::carrier_frequency()']]],
  ['content_5fid',['content_id',['../struct_xe_thru_1_1_data_float.xhtml#ac1b5a2d971b64d156bc9940f13d7bdd4',1,'XeThru::DataFloat']]],
  ['counter',['counter',['../struct_xe_thru_1_1_respiration_moving_list_data.xhtml#a01e91d0b5bd180f3ced73c9f89bcc3d1',1,'XeThru::RespirationMovingListData::counter()'],['../struct_xe_thru_1_1_respiration_detection_list_data.xhtml#a2bd84bf019a02402a9ef2922ebef3359',1,'XeThru::RespirationDetectionListData::counter()']]]
];
