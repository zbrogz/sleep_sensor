var searchData=
[
  ['sample_5ffrequency',['sample_frequency',['../class_xe_thru_1_1_baseband_ap_data.xhtml#abb47ecdc35d1c18316d61a4bf3c83f55',1,'XeThru::BasebandApData::sample_frequency()'],['../class_xe_thru_1_1_baseband_iq_data.xhtml#a0da9e58f2e363874879eab5a806bac1e',1,'XeThru::BasebandIqData::sample_frequency()']]],
  ['sensor_5fstate',['sensor_state',['../class_xe_thru_1_1_respiration_data.xhtml#a26b57851b2cc6a80f6586ce219f3672f',1,'XeThru::RespirationData::sensor_state()'],['../class_xe_thru_1_1_sleep_data.xhtml#a84c537a42edc450c012661e14e26c317',1,'XeThru::SleepData::sensor_state()']]],
  ['signal_5fquality',['signal_quality',['../class_xe_thru_1_1_respiration_data.xhtml#a35c7ff5f1314e0b4898c14056c48e541',1,'XeThru::RespirationData::signal_quality()'],['../class_xe_thru_1_1_sleep_data.xhtml#afa09cedb374c88eba424b2344e9f2953',1,'XeThru::SleepData::signal_quality()'],['../class_xe_thru_1_1_presence_single_data.xhtml#a87d4faa952ea8eee1546a418a3bfb098',1,'XeThru::PresenceSingleData::signal_quality()']]],
  ['start',['start',['../struct_xe_thru_1_1_detection_zone_limits.xhtml#ab85333832425c91717b18c5430cda0e9',1,'XeThru::DetectionZoneLimits::start()'],['../struct_xe_thru_1_1_frame_area.xhtml#a6c516fecd06519177b24a2599a00b723',1,'XeThru::FrameArea::start()'],['../struct_xe_thru_1_1_detection_zone.xhtml#a6b12253104a02a07d73f2c8d5e326668',1,'XeThru::DetectionZone::start()']]],
  ['step',['step',['../struct_xe_thru_1_1_detection_zone_limits.xhtml#a2466924dbd845052abbfd9d1d7685a55',1,'XeThru::DetectionZoneLimits']]]
];
