var searchData=
[
  ['abbreviations_2emd',['abbreviations.md',['../abbreviations_8md.xhtml',1,'']]]
];
