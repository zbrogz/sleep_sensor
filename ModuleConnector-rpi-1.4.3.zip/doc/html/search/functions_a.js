var searchData=
[
  ['open',['open',['../class_xe_thru_1_1_data_reader.xhtml#a0bdad4516ec41f83dc6aefd0af6adc51',1,'XeThru::DataReader::open()'],['../class_xe_thru_1_1_module_connector.xhtml#a89f2ac50bc31624dfabcb3afdf53f11b',1,'XeThru::ModuleConnector::open()']]],
  ['open_5ffile',['open_file',['../class_xe_thru_1_1_x_e_p.xhtml#a77948021f4bceb9aca8c3ba0f776bf94',1,'XeThru::XEP']]],
  ['operator_3d',['operator=',['../class_xe_thru_1_1_preferred_split_size.xhtml#a927026210f32a8624b93a2d44197ab96',1,'XeThru::PreferredSplitSize::operator=(const PreferredSplitSize &amp;other)'],['../class_xe_thru_1_1_preferred_split_size.xhtml#a017574285c536aa702b2f7102e34e906',1,'XeThru::PreferredSplitSize::operator=(PreferredSplitSize &amp;&amp;other)'],['../class_xe_thru_1_1_recording_options.xhtml#a1709ab65743101539283cf5f3a7f9ef8',1,'XeThru::RecordingOptions::operator=(const RecordingOptions &amp;other)'],['../class_xe_thru_1_1_recording_options.xhtml#a36a3c0107fddf78a1a0eef9599e66bf8',1,'XeThru::RecordingOptions::operator=(RecordingOptions &amp;&amp;other)']]]
];
