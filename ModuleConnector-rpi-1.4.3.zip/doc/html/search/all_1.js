var searchData=
[
  ['basebandapdata',['BasebandApData',['../class_xe_thru_1_1_baseband_ap_data.xhtml',1,'XeThru']]],
  ['basebandapdata',['BasebandApData',['../class_xe_thru_1_1_baseband_ap_data.xhtml#a6417943b3f45b8e873726fda89de9cc4',1,'XeThru::BasebandApData::BasebandApData()'],['../class_xe_thru_1_1_baseband_ap_data.xhtml#a00bf476e950a70db8751b64eb47974db',1,'XeThru::BasebandApData::BasebandApData(uint32_t frame_counter, uint32_t num_bins, float bin_length, float sample_frequency, float carrier_frequency, float range_offset, const float *amplitude, const float *phase)']]],
  ['basebandiqdata',['BasebandIqData',['../class_xe_thru_1_1_baseband_iq_data.xhtml',1,'XeThru']]],
  ['basebandiqdata',['BasebandIqData',['../class_xe_thru_1_1_baseband_iq_data.xhtml#aa6d11e58bf58dca5631e061a251eeef6',1,'XeThru::BasebandIqData::BasebandIqData()'],['../class_xe_thru_1_1_baseband_iq_data.xhtml#a32cf74ed624ca827b14cf9adae92e0ce',1,'XeThru::BasebandIqData::BasebandIqData(uint32_t frame_counter, uint32_t num_bins, float bin_length, float sample_frequency, float carrier_frequency, float range_offset, const float *i, const float *q)']]],
  ['bin_5flength',['bin_length',['../class_xe_thru_1_1_baseband_ap_data.xhtml#a4184888b25bdac34114a7b9a202c6a16',1,'XeThru::BasebandApData::bin_length()'],['../class_xe_thru_1_1_baseband_iq_data.xhtml#a397769bc593255d9dfc3c4f78fe1baa9',1,'XeThru::BasebandIqData::bin_length()']]],
  ['byte_5fstep_5fsize',['byte_step_size',['../class_xe_thru_1_1_pulse_doppler_byte_data.xhtml#a1e72f01beb2964943f0f21fe92503f3d',1,'XeThru::PulseDopplerByteData']]],
  ['byte_5fstep_5fstart',['byte_step_start',['../class_xe_thru_1_1_pulse_doppler_byte_data.xhtml#a985a897113dcdb5664f4f35bcd7cc001',1,'XeThru::PulseDopplerByteData']]],
  ['bytecounttype',['ByteCountType',['../class_xe_thru_1_1_preferred_split_size.xhtml#aa3925e25841418f586dc426494303057acabf1995f1b0dddce901954230ede847',1,'XeThru::PreferredSplitSize']]]
];
