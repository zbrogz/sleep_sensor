var searchData=
[
  ['durationtype',['DurationType',['../class_xe_thru_1_1_preferred_split_size.xhtml#aa3925e25841418f586dc426494303057ac920990ae172ddd5f9c296a887bccea1',1,'XeThru::PreferredSplitSize']]]
];
