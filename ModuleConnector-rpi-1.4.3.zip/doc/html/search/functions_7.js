var searchData=
[
  ['is_5fopen',['is_open',['../class_xe_thru_1_1_data_reader.xhtml#aca5f066bb4abf600cd15b4784a83b8ec',1,'XeThru::DataReader']]],
  ['is_5frecording',['is_recording',['../class_xe_thru_1_1_data_recorder.xhtml#a2f41cd9969ee450d4f657e5208fe173a',1,'XeThru::DataRecorder']]]
];
