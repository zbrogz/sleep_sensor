var searchData=
[
  ['preferredsplitsize_2ehpp',['PreferredSplitSize.hpp',['../_preferred_split_size_8hpp.xhtml',1,'']]]
];
