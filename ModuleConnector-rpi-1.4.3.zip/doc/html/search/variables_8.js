var searchData=
[
  ['num_5fbins',['num_bins',['../class_xe_thru_1_1_baseband_ap_data.xhtml#a4a0a4507cfac8ed434b8c2d61a89d2ed',1,'XeThru::BasebandApData::num_bins()'],['../class_xe_thru_1_1_baseband_iq_data.xhtml#a9f5dec94ac829d6ac3e8106ba1bd3b74',1,'XeThru::BasebandIqData::num_bins()']]]
];
