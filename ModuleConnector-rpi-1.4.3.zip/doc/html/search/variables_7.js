var searchData=
[
  ['matrix_5fcounter',['matrix_counter',['../class_xe_thru_1_1_pulse_doppler_float_data.xhtml#acf77e33db751e7fd1c3096261468b634',1,'XeThru::PulseDopplerFloatData::matrix_counter()'],['../class_xe_thru_1_1_pulse_doppler_byte_data.xhtml#aefe119694aa32deb310ef3c5be3de7e1',1,'XeThru::PulseDopplerByteData::matrix_counter()']]],
  ['movement',['movement',['../class_xe_thru_1_1_respiration_data.xhtml#ad5145b6ebf18ed9927be0d1c1e6ba56b',1,'XeThru::RespirationData']]],
  ['movement_5ffast',['movement_fast',['../class_xe_thru_1_1_sleep_data.xhtml#a00552c8357f114da504a98972eb640f5',1,'XeThru::SleepData']]],
  ['movement_5ffast_5fitems',['movement_fast_items',['../class_xe_thru_1_1_presence_moving_list_data.xhtml#a18dd898d5b69bec490218fa8d3ca8220',1,'XeThru::PresenceMovingListData::movement_fast_items()'],['../struct_xe_thru_1_1_respiration_moving_list_data.xhtml#a52c2b70e2088bc4b0582376862e4b6f3',1,'XeThru::RespirationMovingListData::movement_fast_items()']]],
  ['movement_5fslow',['movement_slow',['../class_xe_thru_1_1_sleep_data.xhtml#a2a29884a78379c406ee8c79bddeedcf3',1,'XeThru::SleepData']]],
  ['movement_5fslow_5fitems',['movement_slow_items',['../class_xe_thru_1_1_presence_moving_list_data.xhtml#ae4a66a3758eb2dc7c86c5f86b5088c59',1,'XeThru::PresenceMovingListData::movement_slow_items()'],['../struct_xe_thru_1_1_respiration_moving_list_data.xhtml#a1386edbc2d82e6f093801091cc057ed7',1,'XeThru::RespirationMovingListData::movement_slow_items()']]]
];
