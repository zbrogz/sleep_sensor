var searchData=
[
  ['radar_5fcross_5fsection_5fitems',['radar_cross_section_items',['../class_xe_thru_1_1_presence_moving_list_data.xhtml#afee701a2e318ec218b774ab0a74aeeb3',1,'XeThru::PresenceMovingListData']]],
  ['range',['range',['../class_xe_thru_1_1_pulse_doppler_float_data.xhtml#a6cb4bd8c51255d5681e83954940931e1',1,'XeThru::PulseDopplerFloatData::range()'],['../class_xe_thru_1_1_pulse_doppler_byte_data.xhtml#a5258e9d5a989f72068d4505f66c894b8',1,'XeThru::PulseDopplerByteData::range()']]],
  ['range_5fbins',['range_bins',['../class_xe_thru_1_1_pulse_doppler_float_data.xhtml#a01e5534b131baa25047a6588e3e3d76d',1,'XeThru::PulseDopplerFloatData::range_bins()'],['../class_xe_thru_1_1_pulse_doppler_byte_data.xhtml#a4971cf0a91233a2876b350e3cd529ec1',1,'XeThru::PulseDopplerByteData::range_bins()']]],
  ['range_5fidx',['range_idx',['../class_xe_thru_1_1_pulse_doppler_float_data.xhtml#aade2aefd320fa60dd2302572229a71b6',1,'XeThru::PulseDopplerFloatData::range_idx()'],['../class_xe_thru_1_1_pulse_doppler_byte_data.xhtml#a981e45fcea9ab63510723c370cf0c379',1,'XeThru::PulseDopplerByteData::range_idx()']]],
  ['range_5foffset',['range_offset',['../class_xe_thru_1_1_baseband_ap_data.xhtml#a20b39c86a5830a5e55564a3453957aaf',1,'XeThru::BasebandApData::range_offset()'],['../class_xe_thru_1_1_baseband_iq_data.xhtml#a5e8941d55578bb9c4f0d22bac2d0c86e',1,'XeThru::BasebandIqData::range_offset()']]],
  ['respiration_5frate',['respiration_rate',['../class_xe_thru_1_1_respiration_data.xhtml#a2626305b565623c3f1ebdebba1208224',1,'XeThru::RespirationData::respiration_rate()'],['../class_xe_thru_1_1_sleep_data.xhtml#ac7246b0c56d2f41b530542f23836f5ce',1,'XeThru::SleepData::respiration_rate()']]]
];
