var searchData=
[
  ['is_5fopen',['is_open',['../classpymoduleconnector_1_1moduleconnectorwrapper_1_1_py_data_reader.xhtml#a1eb3c4cec3f2ff9d5a84966bbad60674',1,'pymoduleconnector::moduleconnectorwrapper::PyDataReader']]],
  ['is_5frecording',['is_recording',['../classpymoduleconnector_1_1moduleconnectorwrapper_1_1_py_data_recorder.xhtml#a9686c460b0b212a734076e232ff62bee',1,'pymoduleconnector::moduleconnectorwrapper::PyDataRecorder']]]
];
